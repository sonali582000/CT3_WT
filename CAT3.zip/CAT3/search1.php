<?php
include 'conn.php';
if(isset($_POST['submit']))
{
$sid = $_POST['id'];
?>

<html>
<head>
		<title>User-Login</title>
		
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
	</head>
<body class="login">
<body class="login">
		<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
				<div class="logo margin-top-30">
				<a href="index.html"><h2> CHRIST | Search</h2></a>
				</div>

				<div class="box-login">
					<form class="form-login" method="post">
						<fieldset>
							<legend>
								Sign in to your account
							</legend>
							<form class="form-login" method="post">
							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="id" placeholder="Student ID">
									<i class="fa fa-user"></i> </span>
							</div>
							
								<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" name="submit">
									Login <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
							</form>
</body>
</html>
<br>
<br>
<br>
<table align="center" border="1">
<tr>
<th>Student Name</th>
<th>Age</th>
<th>Gender</th>
<th>Course</th>
<th>Address</th>
</tr>
<?php

$sel="SELECT stu_name,age,gender,course,address FROM `stuinfo` where stu_id='".$sid."';";

	$res=$con->query($sel);
	while($f=$res->fetch_object())
	{
?>
<style>
a{
	text-decoration:none;
}
</style>
		<tr>
		<td><?php echo $f->stu_name;?></td>
		<td><?php echo $f->age;?></td>
		<td><?php echo $f->gender;?></td>
		<td><?php echo $f->course;?></td>
		<td><?php echo $f->address;?></td>
		</tr>
	<?php
	}
	}
	?>
</table>	
