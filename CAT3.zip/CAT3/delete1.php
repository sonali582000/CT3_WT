<?php
include 'conn.php';
$id=$_REQUEST['fid'];
//echo $id;
$query = "DELETE FROM `stuinfo` WHERE stu_id=$id"; 
if (mysqli_query($con,$query))
{
echo "<script>alert('Deleted Successfully');</script>";
header('location:update.php');
}
else
{
echo "<script>alert('Fail');</script>";
}
?>
