<?php
include 'conn.php';
$id=$_REQUEST['fid'];
//echo $fid;
$query = "SELECT stu_name,age,gender,course,address FROM `stuinfo` where stu_id='".$id."';"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<?php  
if(isset($_POST['submit']))
{
$d1=$_POST['stu_name'];
$d2=$_POST['age'];
$d3=$_POST['gender'];
$d4=$_POST['course'];
$d5=$_POST['address'];

$update="UPDATE `stuinfo` SET `stu_name`='".$d1."',`age`='".$d2."',`gender`='".$d3."',`course`='".$d4."',`address`='".$d5."' where stu_id='".$id."'";
if (mysqli_query($con, $update)) 
{
echo "<script>alert('Updated Successfully');</script>";
header('location:update.php');
}
else
{
echo "<script>alert('Fail');</script>";
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<font color="#33CC99"><h2>Update Record</h2></font>
<hr />
</head>
<body>
<form name="form" method="post" action=""> 
  <p>
  <input type="hidden" name="new" value="1" />
  <input name="id" type="hidden" value="<?php echo $row['stu_id'];?>" />
  </p>
  <table width="233" border="1" cellpadding="2">
    <tr>
      <td width="69">Name </td>
      <td width="144" height="36"><input type="text" name="stu_name" placeholder="Enter Name" 
required="required" value="<?php echo $row['stu_name'];?>" /></td>
    </tr>
    <tr>
      <td height="37">Age </td>
      <td><input type="text" name="age" placeholder="Enter Age" 
required="required" value="<?php echo $row['age'];?>" /></td>
    </tr>
    <tr>
      <td>Gender</td>
      <td><input type="text" name="gender" placeholder="Enter Gender" 
required="required" value="<?php echo $row['gender'];?>" /></td>
    </tr>
    <tr>
      <td>Course</td>
      <td><input type="text" name="course" placeholder="Enter Course" 
required="required" value="<?php echo $row['course'];?>" /></td>
    </tr>
    <tr>
      <td>Address</td>
      <td><input type="text" name="address" placeholder="Enter Age" 
required="required" value="<?php echo $row['address'];?>" /></td>
    </tr>
    <tr>
      <td colspan="2"><center><input name="submit" type="submit" value="Update" /></center></td>
    </tr>
  </table>
  <p>&nbsp;    </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>

</body>
</html>
