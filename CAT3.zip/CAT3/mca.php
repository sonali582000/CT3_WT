<?php
include 'conn.php';
?>
<font color="#33CC66"><h2>CHRIST | MCA Student Information</h2></font>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<hr />
<style>
th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #04AA6D;
  color: white;
}
 .button {
        display: inline-block;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        color: #ffffff;
        background-color: #7aa8b7;
        border-radius: 6px;
        outline: none;
      }
    </style>
</style>
</head>
<table align="center" border="0" width="406">
<tr>
<th width="134">ID</th>
<th width="262">Student Name</th>

</tr>
<?php
$sel="SELECT stu_id,stu_name FROM `stuinfo` where course='MCA';";

	$res=$con->query($sel);
	while($f=$res->fetch_object())
	{
?>
<style>
a{
	text-decoration:none;
}
</style>
		<tr>
				<td><?php echo $f->stu_id;?></td>
						<td><?php echo $f->stu_name;?></td>
		</tr>
	<?php
	}
	?>
</table>
</h2>
<center>
	  <a class="button" href="index/index.html">Logout</a></center>
</body>
</html>
